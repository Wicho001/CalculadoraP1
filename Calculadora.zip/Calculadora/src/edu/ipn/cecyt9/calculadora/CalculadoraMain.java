
package edu.ipn.cecyt9.calculadora;

/**
 * Ejercicio: Calculadora basica 
 * Implementar la Interfaz de usuario 
 * Implementar los metodos siguientes a través de los listeners adecuados: 
 * - Sumar 
 * - Restar 
 * - Multiplicar 
 * - Dividir
 * 
 *@author:  emmanuel 
 * @version:  1.0 
 */
public class CalculadoraMain {
 public static void main(String[] args) {
		Calculadora calculadora = new Calculadora();
		calculadora.setVisible(true);
	}   
}
